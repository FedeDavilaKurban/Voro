
for smooth_mult in [1,2,3,4,5]:
    exec(open("./reconnew.py").read())
    
